#!/bin/bash

# Azure deployment script for AI Interview Assistant
# Make sure to install Azure CLI and login first: az login

# Configuration
RESOURCE_GROUP="interview-assistant-rg"
LOCATION="eastus"
APP_SERVICE_PLAN="interview-assistant-plan"
APP_NAME="interview-assistant-api"
CONTAINER_REGISTRY="interviewassistantregistry"

# Create resource group if it doesn't exist
az group create --name $RESOURCE_GROUP --location $LOCATION

# Create Azure Container Registry if it doesn't exist
az acr create --resource-group $RESOURCE_GROUP --name $CONTAINER_REGISTRY --sku Basic
az acr update --name $CONTAINER_REGISTRY --admin-enabled true

# Get ACR credentials
ACR_USERNAME=$(az acr credential show --name $CONTAINER_REGISTRY --query "username" -o tsv)
ACR_PASSWORD=$(az acr credential show --name $CONTAINER_REGISTRY --query "passwords[0].value" -o tsv)

# Build and push Docker image to ACR
az acr build --registry $CONTAINER_REGISTRY --image $APP_NAME:latest .

# Create App Service Plan if it doesn't exist
az appservice plan create --name $APP_SERVICE_PLAN --resource-group $RESOURCE_GROUP --is-linux --sku P1V2

# Create Web App for Containers if it doesn't exist
az webapp create --resource-group $RESOURCE_GROUP --plan $APP_SERVICE_PLAN --name $APP_NAME \
  --docker-registry-server-url https://$CONTAINER_REGISTRY.azurecr.io \
  --docker-registry-server-user $ACR_USERNAME \
  --docker-registry-server-password $ACR_PASSWORD \
  --deployment-container-image-name $CONTAINER_REGISTRY.azurecr.io/$APP_NAME:latest

# Configure Web App settings from .env file
echo "Configuring app settings from .env file..."
while IFS='=' read -r key value
do
  # Skip comments and empty lines
  [[ $key == \#* ]] && continue
  [[ -z "$key" ]] && continue
  
  # Remove quotes from value
  value=$(echo $value | sed 's/^"\(.*\)"$/\1/')
  
  echo "Setting $key"
  az webapp config appsettings set --resource-group $RESOURCE_GROUP --name $APP_NAME --settings "$key=$value"
done < .env

# Configure diagnostic logs
az webapp log config --resource-group $RESOURCE_GROUP --name $APP_NAME --docker-container-logging filesystem

echo "Deployment completed successfully!"
echo "Your API is now available at: https://$APP_NAME.azurewebsites.net"