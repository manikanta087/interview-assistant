# app/core/config.py
from pydantic import BaseSettings, AnyHttpUrl
from typing import List, Optional, Dict, Any
import secrets
from functools import lru_cache

class Settings(BaseSettings):
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str = secrets.token_urlsafe(32)
    
    # CORS settings
    BACKEND_CORS_ORIGINS: List[AnyHttpUrl] = []
    
    # Azure SQL Database
    SQL_SERVER: str
    SQL_DATABASE: str
    SQL_USER: str
    SQL_PASSWORD: str
    DATABASE_URI: Optional[str] = None
    
    # Azure AI Services
    AZURE_OPENAI_API_KEY: str
    AZURE_OPENAI_ENDPOINT: str
    AZURE_OPENAI_API_VERSION: str = "2023-05-15"
    AZURE_OPENAI_DEPLOYMENT: str
    
    # Azure Speech Services
    AZURE_SPEECH_KEY: str
    AZURE_SPEECH_REGION: str
    
    # Azure SignalR
    AZURE_SIGNALR_CONNECTION_STRING: str
    
    # Azure Blob Storage
    AZURE_STORAGE_CONNECTION_STRING: str
    AZURE_STORAGE_CONTAINER_NAME: str = "interview-recordings"
    
    # Auth settings
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 8  # 8 days
    ALGORITHM: str = "HS256"
    
    # Email settings (for notifications)
    SMTP_TLS: bool = True
    SMTP_PORT: Optional[int] = None
    SMTP_HOST: Optional[str] = None
    SMTP_USER: Optional[str] = None
    SMTP_PASSWORD: Optional[str] = None
    EMAILS_FROM_EMAIL: Optional[str] = None
    EMAILS_FROM_NAME: Optional[str] = None
    
    @property
    def SQLALCHEMY_DATABASE_URI(self) -> str:
        if self.DATABASE_URI:
            return self.DATABASE_URI
        return f"mssql+pyodbc://{self.SQL_USER}:{self.SQL_PASSWORD}@{self.SQL_SERVER}/{self.SQL_DATABASE}?driver=ODBC+Driver+17+for+SQL+Server"
    
    class Config:
        case_sensitive = True
        env_file = ".env"

@lru_cache()
def get_settings():
    return Settings()

settings = get_settings()