# app/models/interview.py
from sqlalchemy import Boolean, Column, Integer, String, DateTime, Text, ForeignKey, Float, JSON
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
import uuid

from app.db.base import Base

class InterviewSession(Base):
    __tablename__ = "interview_sessions"
    
    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    job_title = Column(String, nullable=False)
    industry = Column(String, nullable=False)
    experience_level = Column(String, nullable=False)
    status = Column(String, default="created")  # created, in_progress, completed
    overall_score = Column(Float, nullable=True)
    overall_feedback = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    completed_at = Column(DateTime(timezone=True), nullable=True)
    
    # Relationships
    user = relationship("User", backref="interview_sessions")
    questions = relationship("InterviewQuestion", back_populates="session", cascade="all, delete-orphan")

class InterviewQuestion(Base):
    __tablename__ = "interview_questions"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, ForeignKey("interview_sessions.id"), nullable=False)
    question_text = Column(Text, nullable=False)
    order = Column(Integer, nullable=False)
    answer_text = Column(Text, nullable=True)
    answer_audio_url = Column(String, nullable=True)
    score = Column(Float, nullable=True)
    feedback = Column(JSON, nullable=True)
    answered_at = Column(DateTime(timezone=True), nullable=True)
    
    # Relationships
    session = relationship("InterviewSession", back_populates="questions")