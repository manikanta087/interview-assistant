# app/schemas/interview.py
from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any, Union
from datetime import datetime
import re

class InterviewQuestionBase(BaseModel):
    question_text: str
    order: int

class InterviewQuestionCreate(InterviewQuestionBase):
    pass

class InterviewQuestionUpdate(BaseModel):
    answer_text: Optional[str] = None
    answer_audio_url: Optional[str] = None
    score: Optional[float] = None
    feedback: Optional[Dict[str, Any]] = None

class InterviewQuestionInDBBase(InterviewQuestionBase):
    id: int
    session_id: str
    answer_text: Optional[str] = None
    answer_audio_url: Optional[str] = None
    score: Optional[float] = None
    feedback: Optional[Dict[str, Any]] = None
    answered_at: Optional[datetime] = None
    
    class Config:
        orm_mode = True

class InterviewQuestion(InterviewQuestionInDBBase):
    pass

class InterviewSessionBase(BaseModel):
    job_title: str
    industry: str
    experience_level: str

class InterviewSessionCreate(InterviewSessionBase):
    pass

class InterviewSessionUpdate(BaseModel):
    status: Optional[str] = None
    overall_score: Optional[float] = None
    overall_feedback: Optional[str] = None
    completed_at: Optional[datetime] = None

class InterviewSessionInDBBase(InterviewSessionBase):
    id: str
    user_id: str
    status: str
    overall_score: Optional[float] = None
    overall_feedback: Optional[str] = None
    created_at: datetime
    completed_at: Optional[datetime] = None
    
    class Config:
        orm_mode = True

class InterviewSession(InterviewSessionInDBBase):
    questions: List[InterviewQuestion] = []

class InterviewFeedback(BaseModel):
    content_relevance: float = Field(..., ge=1, le=10)
    clarity: float = Field(..., ge=1, le=10)
    technical_accuracy: float = Field(..., ge=1, le=10)
    areas_of_improvement: List[str]
    strengths: List[str]
    suggestions: Optional[str] = None