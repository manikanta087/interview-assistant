# app/services/signalr.py
import json
import logging
import httpx
import base64
import hmac
import hashlib
import urllib.parse
from datetime import datetime, timedelta
from app.core.config import settings

logger = logging.getLogger(__name__)

class AzureSignalRService:
    def __init__(self):
        self.connection_string = settings.AZURE_SIGNALR_CONNECTION_STRING
        self.endpoint, self.access_key = self._parse_connection_string()
    
    def _parse_connection_string(self):
        """Parse the SignalR connection string to extract endpoint and access key"""
        parts = self.connection_string.split(';')
        endpoint = None
        access_key = None
        
        for part in parts:
            if part.startswith('Endpoint='):
                endpoint = part[9:]
            elif part.startswith('AccessKey='):
                access_key = part[10:]
        
        if not endpoint or not access_key:
            raise ValueError("Invalid Azure SignalR connection string")
        
        return endpoint, access_key
    
    def _generate_token(self, hub: str, user_id: str = None):
        """Generate a JWT token for SignalR authentication"""
        # Token expires in 1 hour
        exp = int((datetime.utcnow() + timedelta(hours=1)).timestamp())
        
        # Create the claims
        claims = {
            "aud": self.endpoint,
            "exp": exp
        }
        
        if user_id:
            claims["sub"] = user_id
        
        # Create the token
        token = self._create_jwt_token(claims)
        return token
    
    def _create_jwt_token(self, claims):
        """Create a JWT token with the given claims"""
        header = {"alg": "HS256", "typ": "JWT"}
        
        # Encode the header and claims
        header_bytes = json.dumps(header, separators=(',', ':')).encode('utf-8')
        header_b64 = base64.urlsafe_b64encode(header_bytes).decode('utf-8').rstrip('=')
        
        claims_bytes = json.dumps(claims, separators=(',', ':')).encode('utf-8')
        claims_b64 = base64.urlsafe_b64encode(claims_bytes).decode('utf-8').rstrip('=')
        
        # Create the signature
        signature_input = f"{header_b64}.{claims_b64}"
        signature = hmac.new(
            base64.b64decode(self.access_key), 
            signature_input.encode('utf-8'), 
            hashlib.sha256
        ).digest()
        signature_b64 = base64.urlsafe_b64encode(signature).decode('utf-8').rstrip('=')
        
        # Create the token
        return f"{header_b64}.{claims_b64}.{signature_b64}"
    
    async def send_message(self, hub: str, target: str, arguments: list, user_id: str = None, group_name: str = None):
        """Send a message to a SignalR hub"""
        # Generate the token
        token = self._generate_token(hub, user_id)
        
        # Create the URL
        url = f"{self.endpoint}/api/v1/hubs/{hub}"
        
        if user_id and not group_name:
            # Send to a specific user
            url = f"{url}/users/{urllib.parse.quote(user_id)}"
        elif group_name and not user_id:
            # Send to a group
            url = f"{url}/groups/{urllib.parse.quote(group_name)}"
        
        # Create the headers
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}"
        }
        
        # Create the payload
        payload = {
            "target": target,
            "arguments": arguments
        }
        
        # Send the request
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(url, json=payload, headers=headers)
                response.raise_for_status()
                return True
        except Exception as e:
            logger.error(f"Error sending SignalR message: {str(e)}")
            return False
    
    def get_client_hub_url(self, hub: str, user_id: str = None):
        """Get the URL for clients to connect to the SignalR hub"""
        token = self._generate_token(hub, user_id)
        return f"{self.endpoint}/client/?hub={hub}&access_token={token}"