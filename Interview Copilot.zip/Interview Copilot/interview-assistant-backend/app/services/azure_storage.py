# app/services/azure_storage.py
import os
import uuid
import logging
from datetime import datetime, timedelta
from azure.storage.blob import BlobServiceClient, BlobSasPermissions, generate_blob_sas
from azure.core.exceptions import ResourceExistsError
from app.core.config import settings

logger = logging.getLogger(__name__)

class AzureBlobStorageService:
    def __init__(self):
        self.connection_string = settings.AZURE_STORAGE_CONNECTION_STRING
        self.container_name = settings.AZURE_STORAGE_CONTAINER_NAME
        self.blob_service_client = BlobServiceClient.from_connection_string(self.connection_string)
        
        # Ensure container exists
        try:
            self.blob_service_client.create_container(self.container_name)
            logger.info(f"Container '{self.container_name}' created")
        except ResourceExistsError:
            logger.info(f"Container '{self.container_name}' already exists")
    
    async def upload_file(self, file_path: str, blob_name: str = None, content_type: str = None) -> str:
        """
        Upload a file to Azure Blob Storage and return the URL
        """
        if not blob_name:
            # Generate a unique blob name if not provided
            extension = os.path.splitext(file_path)[1]
            blob_name = f"{uuid.uuid4()}{extension}"
        
        # Get a blob client
        blob_client = self.blob_service_client.get_blob_client(
            container=self.container_name, 
            blob=blob_name
        )
        
        # Upload the file
        with open(file_path, "rb") as data:
            blob_client.upload_blob(data, overwrite=True, content_type=content_type)
        
        # Generate a SAS URL that's valid for 1 day
        sas_token = generate_blob_sas(
            account_name=blob_client.account_name,
            container_name=self.container_name,
            blob_name=blob_name,
            account_key=self.blob_service_client.credential.account_key,
            permission=BlobSasPermissions(read=True),
            expiry=datetime.utcnow() + timedelta(days=1)
        )
        
        # Return the full URL to the blob
        return f"{blob_client.url}?{sas_token}"
    
    async def delete_file(self, blob_name: str) -> bool:
        """
        Delete a file from Azure Blob Storage
        """
        blob_client = self.blob_service_client.get_blob_client(
            container=self.container_name, 
            blob=blob_name
        )
        
        try:
            blob_client.delete_blob()
            return True
        except Exception as e:
            logger.error(f"Error deleting blob {blob_name}: {str(e)}")
            return False