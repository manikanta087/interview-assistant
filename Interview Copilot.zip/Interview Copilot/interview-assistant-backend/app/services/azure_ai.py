# app/services/azure_ai.py
import os
import json
import logging
import httpx
from typing import Dict, Any, List, Optional
import azure.cognitiveservices.speech as speechsdk
from app.core.config import settings

logger = logging.getLogger(__name__)

class AzureAIService:
    def __init__(self):
        self.api_key = settings.AZURE_OPENAI_API_KEY
        self.endpoint = settings.AZURE_OPENAI_ENDPOINT
        self.api_version = settings.AZURE_OPENAI_API_VERSION
        self.deployment = settings.AZURE_OPENAI_DEPLOYMENT
        
    async def call_azure_openai(self, prompt: str, max_tokens: int = 1000, temperature: float = 0.7):
        """
        Call Azure OpenAI service with the given prompt
        """
        url = f"{self.endpoint}/openai/deployments/{self.deployment}/completions?api-version={self.api_version}"
        
        headers = {
            "Content-Type": "application/json",
            "api-key": self.api_key
        }
        
        payload = {
            "prompt": prompt,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "n": 1,
            "stop": None
        }
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(url, json=payload, headers=headers)
                response.raise_for_status()
                result = response.json()
                return result["choices"][0]["text"]
        except Exception as e:
            logger.error(f"Error calling Azure OpenAI: {str(e)}")
            raise
    
    async def generate_interview_questions(
        self, 
        job_title: str, 
        industry: str, 
        experience_level: str,
        count: int = 5
    ) -> List[str]:
        """
        Generate relevant interview questions based on job details
        """
        prompt = f"""
        Generate {count} realistic and challenging interview questions for a {job_title} position 
        in the {industry} industry for a candidate with {experience_level} experience level.
        
        The questions should:
        1. Be specific to the role and industry
        2. Include a mix of technical and behavioral questions
        3. Assess both hard skills and soft skills
        4. Be challenging but fair for the given experience level
        5. Not include any explanations or additional text
        
        Format: Return only a numbered list of questions, one per line.
        
        Example format:
        1. Question one
        2. Question two
        3. Question three
        """
        
        try:
            response = await self.call_azure_openai(prompt, max_tokens=1000, temperature=0.7)
            
            # Parse the response to extract just the questions
            questions = []
            for line in response.strip().split('\n'):
                # Remove question numbers and spaces
                line = line.strip()
                if line and any(line.startswith(f"{i}.") for i in range(1, count+2)):
                    # Remove the number and trim spaces
                    question = re.sub(r'^\d+\.\s*', '', line).strip()
                    if question:
                        questions.append(question)
            
            # Ensure we have exactly the requested number of questions
            return questions[:count]
        except Exception as e:
            logger.error(f"Error generating interview questions: {str(e)}")
            # Fallback to default questions if AI service fails
            return [
                f"What makes you a good candidate for this {job_title} position?",
                f"Describe a challenging situation you've faced in a previous {experience_level} role.",
                "What are your greatest professional strengths and weaknesses?",
                f"How do you stay current with trends in the {industry} industry?",
                "Describe a time when you had to learn a new skill quickly."
            ][:count]
    
    async def analyze_interview_response(
        self, 
        question: str, 
        answer: str, 
        job_title: str,
        industry: str,
        experience_level: str
    ) -> Dict[str, Any]:
        """
        Analyze an interview response using Azure OpenAI
        """
        prompt = f"""
        Analyze this interview response for a {job_title} position in the {industry} industry at {experience_level} level:
        
        Question: {question}
        
        Answer: {answer}
        
        Provide an evaluation in JSON format with the following fields:
        - content_relevance: Rating from 1-10 on how well the answer addresses the question
        - clarity: Rating from 1-10 on the clarity and structure of the answer
        - technical_accuracy: Rating from 1-10 on technical correctness (if applicable)
        - areas_of_improvement: List of specific areas where the answer could be improved
        - strengths: List of strengths in the response
        - suggestions: Specific advice for better answering this type of question
        
        Example format:
        {{
          "content_relevance": 8,
          "clarity": 7,
          "technical_accuracy": 9,
          "areas_of_improvement": ["Could provide more specific examples", "Answer was slightly too long"],
          "strengths": ["Demonstrated good technical knowledge", "Structured response well"],
          "suggestions": "Consider using the STAR method to structure your response more clearly"
        }}
        """
        
        try:
            response = await self.call_azure_openai(prompt, max_tokens=1000, temperature=0.3)
            
            # Extract the JSON part from the response
            json_start = response.find('{')
            json_end = response.rfind('}') + 1
            
            if json_start >= 0 and json_end > json_start:
                json_str = response[json_start:json_end]
                try:
                    feedback = json.loads(json_str)
                    return feedback
                except json.JSONDecodeError:
                    logger.error(f"Failed to parse feedback JSON: {json_str}")
            
            # Fallback if we can't parse the JSON properly
            return {
                "content_relevance": 5,
                "clarity": 5,
                "technical_accuracy": 5,
                "areas_of_improvement": ["Unable to analyze specifically"],
                "strengths": ["Response was provided"],
                "suggestions": "The system was unable to provide specific feedback. Please try again."
            }
        except Exception as e:
            logger.error(f"Error analyzing interview response: {str(e)}")
            return {
                "content_relevance": 5,
                "clarity": 5, 
                "technical_accuracy": 5,
                "areas_of_improvement": ["System error occurred"],
                "strengths": ["Unable to analyze"],
                "suggestions": f"An error occurred while analyzing your response: {str(e)}"
            }

# Add this method to your app/services/azure_ai.py file

    async def generate_interview_copilot_response(
        self, 
        question: str, 
        job_title: str,
        company: str = None,
        industry: str = None,
        interview_history: List[Dict[str, Any]] = None,
        key_skills: List[str] = None
    ) -> Dict[str, Any]:
        """
        Generate a real-time response for an interview question using ChatGPT-style API
        """
        try:
            # Format conversation history if available
            conversation_context = ""
            if interview_history and len(interview_history) > 0:
                conversation_context = "Previous conversation:\n"
                for entry in interview_history:
                    if "interviewer" in entry:
                        conversation_context += f"Interviewer: {entry['interviewer']}\n"
                    if "candidate" in entry:
                        conversation_context += f"Candidate (you): {entry['candidate']}\n"
            
            # Format key skills if available
            skills_context = ""
            if key_skills and len(key_skills) > 0:
                skills_context = "Your key skills and experiences:\n- " + "\n- ".join(key_skills)
            
            # Build the complete prompt
            messages = [
                {
                    "role": "system",
                    "content": f"""You are an expert interview coach providing real-time assistance during a job interview.
                    The user is interviewing for a {job_title} position{f' at {company}' if company else ''}{f' in the {industry} industry' if industry else ''}.
                    
                    Provide concise, insightful responses that the candidate can quickly read and adapt.
                    Keep your answers professional, honest, and tailored to the specific question.
                    Format your response as JSON with these fields:
                    - answer: A complete professional answer (200-300 words)
                    - talking_points: 3-5 key points the candidate should mention (brief bullet points)
                    - avoid_points: 2-3 things the candidate should avoid saying (brief warnings)
                    - confidence_score: A number from 0.0 to 1.0 representing how confident you are in this answer
                    
                    {skills_context}
                    
                    {conversation_context}
                    """
                },
                {
                    "role": "user",
                    "content": f"Interviewer just asked: {question}\n\nPlease help me answer this effectively."
                }
            ]
            
            # Call Azure OpenAI chat API
            url = f"{self.endpoint}/openai/deployments/{self.deployment_chat}/chat/completions?api-version={self.api_version}"
            
            headers = {
                "Content-Type": "application/json",
                "api-key": self.api_key
            }
            
            payload = {
                "messages": messages,
                "temperature": 0.7,
                "max_tokens": 1000,
                "top_p": 0.95,
                "frequency_penalty": 0,
                "presence_penalty": 0,
                "stop": None
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.post(url, json=payload, headers=headers)
                response.raise_for_status()
                result = response.json()
                
                # Extract and parse the JSON response
                content = result["choices"][0]["message"]["content"]
                
                # Extract JSON from the response
                try:
                    # Look for JSON in the content (it might be wrapped in ```json or just be plain JSON)
                    json_start = content.find('{')
                    json_end = content.rfind('}') + 1
                    
                    if json_start >= 0 and json_end > json_start:
                        json_str = content[json_start:json_end]
                        data = json.loads(json_str)
                        
                        # Ensure all required fields are present
                        return {
                            "answer": data.get("answer", ""),
                            "talking_points": data.get("talking_points", []),
                            "avoid_points": data.get("avoid_points", []),
                            "confidence_score": data.get("confidence_score", 0.7)
                        }
                except json.JSONDecodeError:
                    logger.error(f"Failed to parse JSON from response: {content}")
                
                # Fallback if parsing JSON fails
                return {
                    "answer": "I couldn't generate a structured response, but here's my advice:\n\n" + content,
                    "talking_points": ["Be honest", "Keep it concise", "Share relevant examples"],
                    "avoid_points": ["Don't memorize this answer verbatim", "Don't speak too quickly"],
                    "confidence_score": 0.5
                }
        except Exception as e:
            logger.error(f"Error generating interview response: {str(e)}")
            raise Exception(f"Failed to generate interview response: {str(e)}")            