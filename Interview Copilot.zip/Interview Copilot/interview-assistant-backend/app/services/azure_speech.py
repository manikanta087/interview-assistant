# app/services/azure_speech.py
import os
import uuid
import logging
import asyncio
import azure.cognitiveservices.speech as speechsdk
from app.core.config import settings
from app.services.azure_storage import AzureBlobStorageService

logger = logging.getLogger(__name__)

class AzureSpeechService:
    def __init__(self):
        self.speech_key = settings.AZURE_SPEECH_KEY
        self.speech_region = settings.AZURE_SPEECH_REGION
        self.speech_config = speechsdk.SpeechConfig(
            subscription=self.speech_key, 
            region=self.speech_region
        )
        self.storage_service = AzureBlobStorageService()
        
    async def text_to_speech(self, text: str, voice_name: str = "en-US-JennyNeural") -> str:
        """
        Convert text to speech and save the audio file to Azure Blob Storage
        Returns the URL to the audio file
        """
        # Configure speech synthesis
        self.speech_config.speech_synthesis_voice_name = voice_name
        
        # Create a unique filename
        file_name = f"tts_{uuid.uuid4()}.wav"
        file_path = f"/tmp/{file_name}"
        
        # Create the file audio output config
        file_config = speechsdk.audio.AudioOutputConfig(filename=file_path)
        
        # Create the speech synthesizer
        speech_synthesizer = speechsdk.SpeechSynthesizer(
            speech_config=self.speech_config, 
            audio_config=file_config
        )
        
        # Synthesize text
        result = speech_synthesizer.speak_text_async(text).get()
        
        # Check result
        if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
            # Upload to Azure Blob Storage
            blob_url = await self.storage_service.upload_file(file_path, file_name, content_type="audio/wav")
            
            # Clean up temporary file
            os.remove(file_path)
            
            return blob_url
        else:
            error = result.cancellation_details.reason
            logger.error(f"Speech synthesis failed: {error}")
            raise Exception(f"Speech synthesis failed: {error}")
    
    async def speech_to_text(self, audio_file_path: str) -> str:
        """
        Convert speech from audio file to text
        """
        # Create audio configuration using the file
        audio_config = speechsdk.audio.AudioConfig(filename=audio_file_path)
        
        # Create the speech recognizer
        speech_recognizer = speechsdk.SpeechRecognizer(
            speech_config=self.speech_config, 
            audio_config=audio_config
        )
        
        # Start speech recognition
        result = speech_recognizer.recognize_once_async().get()
        
        # Check result
        if result.reason == speechsdk.ResultReason.RecognizedSpeech:
            return result.text
        elif result.reason == speechsdk.ResultReason.NoMatch:
            logger.warning("No speech could be recognized")
            return ""
        elif result.reason == speechsdk.ResultReason.Canceled:
            cancellation = result.cancellation_details
            logger.error(f"Speech recognition canceled: {cancellation.reason}")
            if cancellation.reason == speechsdk.CancellationReason.Error:
                logger.error(f"Error details: {cancellation.error_details}")
            return ""