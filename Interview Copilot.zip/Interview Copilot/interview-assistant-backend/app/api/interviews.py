# app/api/interviews.py
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, BackgroundTasks, Path, Query
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from sqlalchemy import func
import jwt
import uuid
import tempfile
import os
from typing import List, Optional
from datetime import datetime
import asyncio

from app.core.config import settings
from app.core.security import create_access_token
from app.db.session import get_db
from app.models.user import User
from app.models.interview import InterviewSession, InterviewQuestion
from app.schemas.interview import (
    InterviewSessionCreate, 
    InterviewSession as InterviewSessionSchema,
    InterviewQuestion as InterviewQuestionSchema,
    InterviewQuestionUpdate
)
from app.services.azure_ai import AzureAIService
from app.services.azure_speech import AzureSpeechService
from app.services.azure_storage import AzureBlobStorageService
from app.services.signalr import AzureSignalRService

router = APIRouter(prefix="/interviews", tags=["interviews"])
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")
ai_service = AzureAIService()
speech_service = AzureSpeechService()
storage_service = AzureBlobStorageService()
signalr_service = AzureSignalRService()

async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> User:
    try:
        payload = jwt.decode(
            token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
        )
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    if not user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")
    
    return user

@router.post("/", response_model=InterviewSessionSchema)
async def create_interview_session(
    session_data: InterviewSessionCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Create a new mock interview session with AI-generated questions
    """
    # Generate a unique session ID
    session_id = str(uuid.uuid4())
    
    # Create interview session
    db_session = InterviewSession(
        id=session_id,
        user_id=current_user.id,
        job_title=session_data.job_title,
        industry=session_data.industry,
        experience_level=session_data.experience_level,
        status="created"
    )
    db.add(db_session)
    db.flush()  # Flush to get the ID without committing
    
    # Generate interview questions asynchronously
    questions = await ai_service.generate_interview_questions(
        job_title=session_data.job_title,
        industry=session_data.industry,
        experience_level=session_data.experience_level
    )
    
    # Add questions to database
    for i, question_text in enumerate(questions):
        db_question = InterviewQuestion(
            session_id=session_id,
            question_text=question_text,
            order=i + 1
        )
        db.add(db_question)
    
    # Commit all changes
    db.commit()
    db.refresh(db_session)
    
    # Get the full session with questions
    result = db.query(InterviewSession).filter(
        InterviewSession.id == session_id
    ).first()
    
    return result

@router.get("/", response_model=List[InterviewSessionSchema])
def get_user_interview_sessions(
    skip: int = 0, 
    limit: int = 100,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get all interview sessions for the current user
    """
    sessions = db.query(InterviewSession).filter(
        InterviewSession.user_id == current_user.id
    ).offset(skip).limit(limit).all()
    
    return sessions

@router.get("/{session_id}", response_model=InterviewSessionSchema)
def get_interview_session(
    session_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get a specific interview session
    """
    session = db.query(InterviewSession).filter(
        InterviewSession.id == session_id,
        InterviewSession.user_id == current_user.id
    ).first()
    
    if not session:
        raise HTTPException(status_code=404, detail="Interview session not found")
    
    return session

@router.post("/{session_id}/questions/{question_id}/answer")
async def submit_answer(
    session_id: str,
    question_id: int,
    background_tasks: BackgroundTasks,
    answer_text: Optional[str] = None,
    audio_file: Optional[UploadFile] = File(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Submit an answer to an interview question
    """
    # Verify session belongs to user
    session = db.query(InterviewSession).filter(
        InterviewSession.id == session_id,
        InterviewSession.user_id == current_user.id
    ).first()
    
    if not session:
        raise HTTPException(status_code=404, detail="Interview session not found")
    
    # Get the question
    question = db.query(InterviewQuestion).filter(
        InterviewQuestion.id == question_id,
        InterviewQuestion.session_id == session_id
    ).first()
    
    if not question:
        raise HTTPException(status_code=404, detail="Question not found")
    
    # Process audio file if provided
    if audio_file:
        # Save to temporary file
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
        try:
            content = await audio_file.read()
            temp_file.write(content)
            temp_file.close()
            
            # Convert speech to text
            answer_text = await speech_service.speech_to_text(temp_file.name)
            
            # Upload audio to blob storage
            blob_name = f"interview_{session_id}_question_{question_id}.wav"
            audio_url = await storage_service.upload_file(
                temp_file.name, 
                blob_name, 
                content_type="audio/wav"
            )
            
            # Update question with audio URL
            question.answer_audio_url = audio_url
        finally:
            # Clean up temp file
            os.unlink(temp_file.name)
    
    if not answer_text:
        raise HTTPException(status_code=400, detail="Either answer_text or audio_file must be provided")
    
    # Update question with answer text
    question.answer_text = answer_text
    question.answered_at = datetime.utcnow()
    
    # Update session status if this is the first answer
    if session.status == "created":
        session.status = "in_progress"
    
    db.commit()
    
    # Analyze the answer in the background
    background_tasks.add_task(
        analyze_answer_and_update,
        question_id=question_id,
        session_id=session_id,
        user_id=current_user.id
    )
    
    return {"message": "Answer submitted successfully", "is_analyzing": True}

@router.post("/{session_id}/complete")
async def complete_interview(
    session_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Mark an interview session as complete and generate overall feedback
    """
    # Verify session belongs to user
    session = db.query(InterviewSession).filter(
        InterviewSession.id == session_id,
        InterviewSession.user_id == current_user.id
    ).first()
    
    if not session:
        raise HTTPException(status_code=404, detail="Interview session not found")
    
    # Check if all questions have been answered
    questions = db.query(InterviewQuestion).filter(
        InterviewQuestion.session_id == session_id
    ).all()
    
    unanswered = [q for q in questions if q.answer_text is None]
    if unanswered:
        raise HTTPException(
            status_code=400, 
            detail=f"{len(unanswered)} questions are still unanswered"
        )
    
    # Calculate overall score (average of question scores)
    total_score = sum(q.score or 0 for q in questions)
    avg_score = total_score / len(questions) if questions else 0
    
    # Generate overall feedback
    prompt = f"""
    Provide comprehensive feedback for this {session.job_title} interview in the {session.industry} industry.
    
    The candidate has the following scores:
    {", ".join([f"Question {i+1}: {q.score or 0}/10" for i, q in enumerate(questions)])}
    
    Average score: {avg_score:.1f}/10
    
    Based on their answers, provide:
    1. Overall assessment (1-2 paragraphs)
    2. Key strengths (3-5 bullet points)
    3. Areas for improvement (3-5 bullet points)
    4. Specific suggestions for preparation before the next interview
    
    Make the feedback constructive, specific, and actionable.
    """
    
    try:
        overall_feedback = await ai_service.call_azure_openai(prompt, max_tokens=1000, temperature=0.5)
    except Exception as e:
        overall_feedback = f"Unable to generate feedback due to an error: {str(e)}"
    
    # Update session
    session.overall_score = avg_score
    session.overall_feedback = overall_feedback
    session.status = "completed"
    session.completed_at = datetime.utcnow()
    
    db.commit()
    
    return {
        "message": "Interview completed successfully",
        "overall_score": avg_score,
        "overall_feedback": overall_feedback
    }

async def analyze_answer_and_update(question_id: int, session_id: str, user_id: str):
    """
    Background task to analyze an answer and update the database
    """
    # Get a new database session (not tied to request lifecycle)
    db = SessionLocal()
    try:
        # Get the question and session
        question = db.query(InterviewQuestion).filter(InterviewQuestion.id == question_id).first()
        session = db.query(InterviewSession).filter(InterviewSession.id == session_id).first()
        
        if not question or not session:
            return
        
        # Analyze the answer
        feedback = await ai_service.analyze_interview_response(
            question=question.question_text,
            answer=question.answer_text,
            job_title=session.job_title,
            industry=session.industry,
            experience_level=session.experience_level
        )
        
        # Calculate score (average of content_relevance, clarity, and technical_accuracy)
        score = (
            feedback.get("content_relevance", 0) + 
            feedback.get("clarity", 0) + 
            feedback.get("technical_accuracy", 0)
        ) / 3
        
        # Update the question
        question.feedback = feedback
        question.score = score
        db.commit()
        
        # Notify the client via SignalR
        await signalr_service.send_message(
            hub="interviewhub",
            target="ReceiveFeedback",
            arguments=[{
                "questionId": question_id,
                "feedback": feedback,
                "score": score
            }],
            user_id=user_id
        )
    finally:
        db.close()