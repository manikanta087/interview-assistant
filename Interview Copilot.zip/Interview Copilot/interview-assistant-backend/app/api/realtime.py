# app/api/realtime.py
from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.security import OAuth2PasswordBearer
import jwt
import json
import logging
from sqlalchemy.orm import Session
from typing import Dict, List, Any

from app.core.config import settings
from app.db.session import get_db
from app.models.user import User
from app.models.interview import InterviewSession
from app.services.azure_ai import AzureAIService
from app.services.signalr import AzureSignalRService

router = APIRouter(prefix="/realtime", tags=["realtime"])
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")
ai_service = AzureAIService()
signalr_service = AzureSignalRService()
logger = logging.getLogger(__name__)

# Store active connections
active_connections: Dict[str, Dict[str, WebSocket]] = {}

@router.get("/signalr-info")
async def get_signalr_info(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
):
    """
    Get SignalR connection information for the client
    """
    try:
        payload = jwt.decode(
            token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
        )
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Get SignalR URL for the client
    hub_url = signalr_service.get_client_hub_url("interviewhub", user_id)
    
    return {
        "hub_url": hub_url,
        "user_id": user_id
    }

@router.websocket("/ws/{session_id}")
async def websocket_endpoint(
    websocket: WebSocket, 
    session_id: str
):
    await websocket.accept()
    
    # Store client connection
    if session_id not in active_connections:
        active_connections[session_id] = {}
    
    client_id = id(websocket)
    active_connections[session_id][client_id] = websocket
    
    try:
        while True:
            # Receive message from client
            data = await websocket.receive_text()
            message = json.loads(data)
            
            # Check message type
            if message["type"] == "transcript":
                # Process live interview transcript
                transcript = message.get("text", "")
                context = message.get("context", {})
                
                # Generate real-time suggestions using AI
                prompt = f"""
                You are an interview coach providing real-time advice during a job interview.
                
                The candidate is interviewing for a {context.get('job_title', 'job')} position.
                
                Here is the recent part of the interview transcript:
                {transcript}
                
                Provide very brief, concise advice (maximum 1-2 sentences) on how to improve 
                the candidate's response or what points they should emphasize.
                
                Your advice should be extremely concise and immediately actionable.
                """
                
                try:
                    suggestion = await ai_service.call_azure_openai(
                        prompt, 
                        max_tokens=100, 
                        temperature=0.7
                    )
                    
                    # Send suggestion back to the client
                    await websocket.send_text(json.dumps({
                        "type": "suggestion",
                        "text": suggestion.strip()
                    }))
                except Exception as e:
                    logger.error(f"Error generating suggestion: {str(e)}")
                    await websocket.send_text(json.dumps({
                        "type": "error",
                        "message": "Failed to generate suggestion"
                    }))
    except WebSocketDisconnect:
        # Remove connection when client disconnects
        if session_id in active_connections:
            active_connections[session_id].pop(client_id, None)
            if not active_connections[session_id]:
                active_connections.pop(session_id, None)
    except Exception as e:
        logger.error(f"WebSocket error: {str(e)}")
        # Attempt to gracefully close if possible
        try:
            await websocket.close()
        except:
            pass