# app/api/copilot.py
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from fastapi.security import OAuth2PasswordBearer
import jwt
import json
import logging
from sqlalchemy.orm import Session
from typing import Dict, List, Any, Optional
from pydantic import BaseModel

from app.core.config import settings
from app.db.session import get_db
from app.models.user import User
from app.services.azure_ai import AzureAIService

router = APIRouter(prefix="/copilot", tags=["copilot"])
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")
ai_service = AzureAIService()
logger = logging.getLogger(__name__)

# Schema for interview context
class InterviewContext(BaseModel):
    job_title: str
    company: Optional[str] = None
    industry: Optional[str] = None
    interviewer_names: Optional[List[str]] = None
    interview_stage: Optional[str] = None
    key_skills: Optional[List[str]] = None
    interview_history: Optional[List[Dict[str, Any]]] = []

# Schema for copilot request
class CopilotRequest(BaseModel):
    question: str
    context: InterviewContext

# Schema for copilot response
class CopilotResponse(BaseModel):
    answer: str
    talking_points: List[str]
    avoid_points: List[str]
    confidence_score: float

async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> User:
    try:
        payload = jwt.decode(
            token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
        )
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    if not user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")
    
    return user

@router.post("/generate", response_model=CopilotResponse)
async def generate_interview_response(
    request: CopilotRequest,
    current_user: User = Depends(get_current_user)
):
    """
    Generate a real-time response for an interview question
    """
    try:
        # Call the AI service to generate a response
        response = await ai_service.generate_interview_copilot_response(
            question=request.question,
            job_title=request.context.job_title,
            company=request.context.company,
            industry=request.context.industry,
            interview_history=request.context.interview_history,
            key_skills=request.context.key_skills
        )
        
        return response
    except Exception as e:
        logger.error(f"Error generating copilot response: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate response: {str(e)}")

@router.post("/conversation/save")
async def save_conversation(
    context: InterviewContext,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Save an interview conversation for future reference
    """
    try:
        # Here you would implement conversation saving logic
        # For example, saving to a new model InterviewConversation
        # For this example, we'll just return success
        return {"success": True, "message": "Conversation saved successfully"}
    except Exception as e:
        logger.error(f"Error saving conversation: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to save conversation: {str(e)}")