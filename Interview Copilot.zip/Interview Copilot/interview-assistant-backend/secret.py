import secrets
print(secrets.token_urlsafe(32))