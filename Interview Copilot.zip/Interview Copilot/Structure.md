interview-assistant-backend/
├── app/
│   ├── api/
│   │   ├── __init__.py
│   │   ├── auth.py
│   │   ├── interviews.py
│   │   ├── documents.py
│   │   └── realtime.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── config.py
│   │   ├── security.py
│   │   └── dependencies.py
│   ├── db/
│   │   ├── __init__.py
│   │   ├── base.py
│   │   └── session.py
│   ├── models/
│   │   ├── __init__.py
│   │   ├── user.py
│   │   └── interview.py
│   ├── schemas/
│   │   ├── __init__.py
│   │   ├── user.py
│   │   └── interview.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── azure_ai.py
│   │   ├── azure_speech.py
│   │   ├── azure_storage.py
│   │   └── signalr.py
│   └── main.py
├── migrations/
│   └── ...
├── .env
├── requirements.txt
├── Dockerfile
└── docker-compose.yml